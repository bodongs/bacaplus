<?php


$uid="Facebook_809123682772493";
$raw_uid="aad00cd6-1476-4826-bf89-bcd864e19b1f";
$user_name="Rezza+Priatna";
$invite_code="F3hl4ip8jV";
$own_mac="02%3A00%3A00%3A00%3A00%3A00";
$android_id="dbc1d4ff0410c399";
$device_type="vivo++vivo+1606";


?>
