# baca
auto baca
