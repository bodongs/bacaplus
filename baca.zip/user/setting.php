<?php
/* setting bot */
$baca_plus=$red."
──── █▀▄ ▄▀▄ ▄▀ ▄▀▄────$kuning █▀▄ █── █─█ ▄▀▀────$red
──── █▀█ █▀█ █─ █▀█────$kuning █─█ █─▄ █─█ ─▀▄────$red
──── ▀▀─ ▀─▀ ─▀ ▀─▀────$kuning █▀─ ▀▀▀ ─▀─ ▀▀─────$putih
creator:$ijo adidoank$putih || code invite:$ijo F9NAmmRD7x$putih
chanel :$kuning sungging$putih || code invite:$ijo F3NW34owm4".$t;
$msg_baca= "[•] official chanel adi bordir";
$stat_baca=true;
 
?>
